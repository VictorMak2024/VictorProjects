﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;


namespace SorterLineConveyorTesting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //  Control stepper conveyor (16 H) (Address: 01), 3000 RPM (0BB8 H)
        byte[] startcom1 = new byte[] { 0x01, 0x06, 0x00, 0x06, 0x00, 0x01, 0xA8, 0x0B};
        byte[] sc_forward1 = new byte[] { 0x01, 0x06, 0x00, 0x00, 0x00, 0x03, 0xC9, 0XCB};
        byte[] sc_backward1 = new byte[] { 0x01, 0x06, 0x00, 0x00, 0x00, 0x01, 0x48, 0x0A};
        byte[] sc_stop1 = new byte[] { 0x01, 0x06, 0x00, 0x00, 0x00, 0x00, 0x89, 0xCA};
        byte[] sc1_forward = new byte[] { 0xBB, 0x06, 0x00, 0x00, 0x00, 0x01, 0x52, 0x90 }; // new driver (BD-21)
        byte[] sc1_stop = new byte[] { 0xBB, 0x06, 0x00, 0x00, 0x00, 0x00, 0x93, 0x50 }; // new driver (BD-21)

        //  Control stepper conveyor (16 H) (Address: 02)
        byte[] startcom2 = new byte[] { 0x02, 0x06, 0x00, 0x06, 0x00, 0x01, 0xA8, 0x38 };
        byte[] sc_forward2 = new byte[] { 0x02, 0x06, 0x00, 0x00, 0x00, 0x03, 0xC9, 0XF8 };
        byte[] sc_backward2 = new byte[] { 0x02, 0x06, 0x00, 0x00, 0x00, 0x01, 0x48, 0x39 };
        byte[] sc_stop2 = new byte[] { 0x02, 0x06, 0x00, 0x00, 0x00, 0x00, 0x89, 0xF9 };

        //  Control stepper conveyor (16 H) (Address: 03)
        byte[] startcom3 = new byte[] { 0x03, 0x06, 0x00, 0x06, 0x00, 0x01, 0xA9, 0xE9 };
        byte[] sc_forward3 = new byte[] { 0x03, 0x06, 0x00, 0x00, 0x00, 0x03, 0xC8, 0X29 };
        byte[] sc_backward3 = new byte[] { 0x03, 0x06, 0x00, 0x00, 0x00, 0x01, 0x49, 0xE8 };
        byte[] sc_stop3 = new byte[] { 0x03, 0x06, 0x00, 0x00, 0x00, 0x00, 0x88, 0x28 };

        //  Control stepper conveyor (16 H) (Address: 04)
        byte[] startcom4 = new byte[] { 0x04, 0x06, 0x00, 0x06, 0x00, 0x01, 0xA8, 0x5E };
        byte[] sc_forward4 = new byte[] { 0x04, 0x06, 0x00, 0x00, 0x00, 0x03, 0xC9, 0X9E };
        byte[] sc_backward4 = new byte[] { 0x04, 0x06, 0x00, 0x00, 0x00, 0x01, 0x48, 0x5F };
        byte[] sc_stop4 = new byte[] { 0x04, 0x06, 0x00, 0x00, 0x00, 0x00, 0x89, 0x9F };

        public string transitdata;
        public string richtext;
        public string richtext2;
        public int count;
        public int strtoint;
        public int strtoint2;

        void StartCommunicate()
        {
            try
            {
                if (!com485_control_conveyor.IsOpen)
                {
                    com485_control_conveyor.Open();
                }
                com485_control_conveyor.Write(startcom1, 0, startcom1.Length);
                Thread.Sleep(10);
                com485_control_conveyor.Write(startcom2, 0, startcom2.Length);
                Thread.Sleep(10);
                com485_control_conveyor.Write(startcom3, 0, startcom3.Length);
                Thread.Sleep(10);
                com485_control_conveyor.Write(startcom4, 0, startcom4.Length);
                Thread.Sleep(10);
                richTextBox1.Text = transitdata = "Communication mode On !" + "\r\n";


                /*byte[] receive_com485_data_buff = new byte[4096];
                int datareceive_buffsize = com485_control_conveyor.ReadBufferSize;
                int datareceive = com485_control_conveyor.BytesToRead; //(Gets the number of bytes of data in the receive buffer.)  Result: get 0 bytes
                //int data2 = com485_control_conveyor.Read(receive_com485_data_buff, 0, datareceive_buffsize);
                Console.WriteLine(datareceive_buffsize);
                Console.WriteLine(datareceive);
                //Console.WriteLine(data2);*/
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                richTextBox1.Text = ex.Message.ToString();
            }
        }

        void MoveForward(int AddressNo)
        {
            if (!com485_control_conveyor.IsOpen)
            {
                com485_control_conveyor.Open();
            }
            switch (AddressNo)
            {
                case 1:
                    com485_control_conveyor.Write(sc_forward1, 0, sc_forward1.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C1 Move Forward !" + "\r\n";
                    break;
                case 2:
                    com485_control_conveyor.Write(sc_forward2, 0, sc_forward2.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C2 Move Forward !" + "\r\n";
                    break;
                case 3:
                    com485_control_conveyor.Write(sc_forward3, 0, sc_forward3.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C3 Move Forward !" + "\r\n";
                    break;
                case 4:
                    com485_control_conveyor.Write(sc_forward4, 0, sc_forward4.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C4 Move Forward !" + "\r\n";
                    break;
                case 111:   // All Conveyor forward 
                    com485_control_conveyor.Write(sc_forward1, 0, sc_forward1.Length);
                    Thread.Sleep(500);
                    com485_control_conveyor.Write(sc_forward2, 0, sc_forward2.Length);
                    Thread.Sleep(500);
                    com485_control_conveyor.Write(sc_forward3, 0, sc_forward3.Length);
                    Thread.Sleep(500);
                    com485_control_conveyor.Write(sc_forward4, 0, sc_forward4.Length);
                    Thread.Sleep(500);
                    richTextBox1.Text = transitdata = "All Conveyor Move Forward !" + "\r\n";
                    break;
                case 201:
                    com485_control_conveyor.Write(sc1_forward, 0, sc1_forward.Length);
                    break;
            }


        }

        void MoveBackward(int AddressNo)
        {
            if (!com485_control_conveyor.IsOpen)
            {
                com485_control_conveyor.Open();
            }
            switch (AddressNo)
            {
                case 1:
                    com485_control_conveyor.Write(sc_backward1, 0, sc_backward1.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C1 Back Forward !" + "\r\n";
                    break;
                case 2:
                    com485_control_conveyor.Write(sc_backward2, 0, sc_backward2.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C2 Back Forward !" + "\r\n";
                    break;
                case 3:
                    com485_control_conveyor.Write(sc_backward3, 0, sc_backward3.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C3 Back Forward !" + "\r\n";
                    break;
                case 4:
                    com485_control_conveyor.Write(sc_backward4, 0, sc_backward4.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C4 Back Forward !" + "\r\n";
                    break;
                case 111:   // All Conveyor Backward
                    com485_control_conveyor.Write(sc_backward1, 0, sc_backward1.Length);
                    Thread.Sleep(500);
                    com485_control_conveyor.Write(sc_backward2, 0, sc_backward2.Length);
                    Thread.Sleep(500);
                    com485_control_conveyor.Write(sc_backward3, 0, sc_backward3.Length);
                    Thread.Sleep(500);
                    com485_control_conveyor.Write(sc_backward4, 0, sc_backward4.Length);
                    Thread.Sleep(500);
                    richTextBox1.Text = transitdata = "All Conveyor Back Forward !" + "\r\n";
                    break;
            }
        }

        void MoveStop(int AddressNo)
        {
            if (!com485_control_conveyor.IsOpen)
            {
                com485_control_conveyor.Open();
            }
            switch (AddressNo)
            {
                case 1:
                    com485_control_conveyor.Write(sc_stop1, 0, sc_stop1.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C1 Stop !" + "\r\n";
                    break;
                case 2:
                    com485_control_conveyor.Write(sc_stop2, 0, sc_stop2.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C2 Stop !" + "\r\n";
                    break;
                case 3:
                    com485_control_conveyor.Write(sc_stop3, 0, sc_stop3.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C3 Stop !" + "\r\n";
                    break;
                case 4:
                    com485_control_conveyor.Write(sc_stop4, 0, sc_stop4.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "C4 Stop !" + "\r\n";
                    break;
                case 111:
                    com485_control_conveyor.Write(sc_stop1, 0, sc_stop1.Length);
                    Thread.Sleep(100);
                    com485_control_conveyor.Write(sc_stop2, 0, sc_stop2.Length);
                    Thread.Sleep(100);
                    com485_control_conveyor.Write(sc_stop3, 0, sc_stop3.Length);
                    Thread.Sleep(100);
                    com485_control_conveyor.Write(sc_stop4, 0, sc_stop4.Length);
                    Thread.Sleep(100);
                    richTextBox1.Text = transitdata = "All Conveyor Stop !" + "\r\n";
                    break;
                case 201:
                    com485_control_conveyor.Write(sc1_stop, 0, sc1_stop.Length);
                    break;
            }
        }

        private void CRun_Click(object sender, EventArgs e)
        {
            MoveForward(201);
        }

        private void CStop_Click(object sender, EventArgs e)
        {
            MoveStop(201);
        }

        private void CRunBack_Click(object sender, EventArgs e)
        {
            MoveBackward(1);
        }

        private void com485_control_conveyor_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            byte[] buffer = new byte[sp.BytesToRead];
            sp.Read(buffer, 0, buffer.Length);
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            //StartCommunicate();
        }

        private void C2_Forward_Click(object sender, EventArgs e)
        {
            MoveForward(2);
        }

        private void C2_Backward_Click(object sender, EventArgs e)
        {
            MoveBackward(2);
        }

        private void C2_Stop_Click(object sender, EventArgs e)
        {
            MoveStop(2);
        }

        private void C3_Forward_Click(object sender, EventArgs e)
        {
            MoveForward(3);
        }

        private void C3_Backward_Click(object sender, EventArgs e)
        {
            MoveBackward(3);
        }

        private void C3_Stop_Click(object sender, EventArgs e)
        {
            MoveStop(3);
        }

        private void C4_Forward_Click(object sender, EventArgs e)
        {
            MoveForward(4);
        }

        private void C4_Backward_Click(object sender, EventArgs e)
        {
            MoveBackward(4);
        }

        private void C4_Stop_Click(object sender, EventArgs e)
        {
            MoveStop(4);
        }

        private void All_C_Backward_Click(object sender, EventArgs e)
        {
            //MoveBackward(111);
            MoveBackward(111);
        }

        private void All_C_Stop_Click(object sender, EventArgs e)
        {
            MoveStop(111);
        }

        private void All_C_Forward_Click(object sender, EventArgs e)
        {
            MoveForward(111);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            richtext = richTextBox2.Text;
            strtoint = Int32.Parse(richtext);
            richtext2 = richTextBox3.Text;
            strtoint2 = Int32.Parse(richtext2);
            for (int n = 1; n <= strtoint; n++)
            {
                if (!com485_control_conveyor.IsOpen)
                {
                    com485_control_conveyor.Open();
                }
                com485_control_conveyor.Write(sc1_forward, 0, sc1_forward.Length);
                string cdata = "C1 Forward ! " + n +","+ strtoint2 + "\r\n";
                richTextBox1.AppendText(cdata);
                Thread.Sleep(strtoint2);
                com485_control_conveyor.Write(sc1_stop, 0, sc1_stop.Length);
                string c2data = "C1 Backward ! " + n +"," + strtoint2 + "\r\n";
                richTextBox1.AppendText(c2data);
                Thread.Sleep(strtoint2);
            }
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            //richTextBox2.Text = richtext;
            //strtoint = Int32.Parse(richtext);
        }
    }
}
